export function increment(){
    return{
        type:'Increment'
    }
}

export function decrement(){
    return{
        type:'Decrement'
    }
}

export function reset(){
    return{
        type:'Reset'
    }
}