# Welcome to Blossombook!
## About this project

Hello, welcome to my portfolio. This webite highlights and showcases a platform for new talented writers to sell and publish their work. We also make it easy for people to download or purchase these books. These young minds are empowered to reach a wider audience by showing off their skills

## How to run the project

To run the project, we can simply download the zip folder and open it in a code editor. Personally, I ahve chosen VScode. Once we open the folder we can run the html file by right clicking on it.

## Website description
### Home

This page of my webiste is the homepage. I have added few quostes and images for better look. I have added navbar where we can see all the items like Home,about,library and contact. Some SASS components which can be highlighted are:

* Variables - Variables can be seen in the config file where each color component has be declared.
* Custom Properties - I have added custom background color called as --first-color
* Nesting - In scss file nesting is dont for every section of the page.
* Interpolation - I have used @extend property in buttons file where it extends the main btn properties.
* Placeholder Selectors - again this is used in the button section. Placeholder selectors are useful when writing a Sass library where each style rule may or may not be used
* Mixins - I have added mixins for grid style and title text for the homepage
* Functions - I have added a function which changes teh color of the background basd on teh percentage of intensity of the color.





### About me

This section covers information about what this webite does. The footer is alsi same for all the pages where we can quickly access few links.The navigation bar is always the same for all the pages. 




### Student Information
=======================

NAME: Shriya Dikshith

NEU ID: 002921535

