Assignment 5 Part B

Group assignment in Bootstrap:
A restaurant/cafe website homepage which displays menu, gallery, contact and about info.

Project Members:
- Ayushi Patel
- Harshita Singh
- Shreya Gosrani
- Shriya Dikshith
- Sanket Khadke

It contains the following bootstrap components:

1) dropdown: In the nav menu for the "pages" to navigate to different pages
2) form: Used for making reservation as well taking contact info from the user
3) button: They are used for ordering online, sending a message, as well as making a reservation
4) card: It is used to display information on hiring
5) carousel: This component is used to display reviews given by our past customers
6) alert: Used to display "Home delivery available" info
7) progress bar: Made use of progress bars to display our chefs' experience levels
8) close button
9) modal: Modal is used on "Make a Reservation" button as well as on menu items for ordering through home delivery.
10) .nav